const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db'); // Assuming you have a db module for database operations

router.post('/login', async (req, res) => {
  const { email, password, role } = req.body;

  try {
    const query = 'SELECT * FROM users WHERE email = ? AND role = ?';
    const [user] = await db.query(query, [email, role]);

    if (!user) {
      return res.status(401).json({ error: 'Invalid email or role' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.json({ token, user });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
