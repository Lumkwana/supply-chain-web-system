import React, { useState, useEffect } from "react";
import { FaEdit, FaTrash, FaKey } from "react-icons/fa"; // Import icons

const ViewUsers = () => {
  const [users, setUsers] = useState([]);
  const [editingUser, setEditingUser] = useState(null); // State to store the user being edited
  const [editedUser, setEditedUser] = useState({}); // State to store edited user details
  const [currentPage, setCurrentPage] = useState(1); // State for pagination
  const usersPerPage = 5; // Number of users per page

  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      console.log("Fetching users from:", `${API_URL}/users`); // Debugging log
      const response = await fetch(`${API_URL}/users`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      console.log("Fetched users:", data); // Debugging log
      setUsers(data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const handleDeleteUser = async (userId) => {
    try {
      const response = await fetch(`${API_URL}/users/${userId}`, {
        method: "DELETE",
      });
      if (response.ok) {
        fetchUsers();
      }
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };

  const handleEditUser = (user) => {
    setEditingUser(user.id); // Set the user being edited
    setEditedUser(user); // Populate the form with the user's current details
  };

  const handleSaveUser = async () => {
    try {
      const response = await fetch(`${API_URL}/users/${editingUser}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(editedUser),
      });
      if (response.ok) {
        setEditingUser(null); // Exit edit mode
        fetchUsers(); // Refresh the user list
      }
    } catch (error) {
      console.error("Error saving user:", error);
    }
  };

  const handleResetPassword = async (userId) => {
    try {
      const response = await fetch(`${API_URL}/users/${userId}/reset-password`, {
        method: "POST",
      });
      if (response.ok) {
        alert("Password reset successfully!");
      }
    } catch (error) {
      console.error("Error resetting password:", error);
    }
  };

  // Pagination logic
  const indexOfLastUser = currentPage * usersPerPage;
  const indexOfFirstUser = indexOfLastUser - usersPerPage;
  const currentUsers = users.slice(indexOfFirstUser, indexOfLastUser);

  const totalPages = Math.ceil(users.length / usersPerPage);

  return (
    <div className="user-section">
      <h2>Available Users</h2>
      <table className="users-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Surname</th>
            <th>Persal Number</th>
            <th>Email</th>
            <th>Department</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {currentUsers.map((user) => (
            <tr key={user.id}>
              <td>
                {editingUser === user.id ? (
                  <input
                    type="text"
                    value={editedUser.username}
                    onChange={(e) =>
                      setEditedUser({ ...editedUser, username: e.target.value })
                    }
                  />
                ) : (
                  user.username
                )}
              </td>
              <td>
                {editingUser === user.id ? (
                  <input
                    type="text"
                    value={editedUser.surname}
                    onChange={(e) =>
                      setEditedUser({ ...editedUser, surname: e.target.value })
                    }
                  />
                ) : (
                  user.surname
                )}
              </td>
              <td>
                {editingUser === user.id ? (
                  <input
                    type="text"
                    value={editedUser.persal_number}
                    onChange={(e) =>
                      setEditedUser({
                        ...editedUser,
                        persal_number: e.target.value,
                      })
                    }
                  />
                ) : (
                  user.persal_number
                )}
              </td>
              <td>
                {editingUser === user.id ? (
                  <input
                    type="email"
                    value={editedUser.email}
                    onChange={(e) =>
                      setEditedUser({ ...editedUser, email: e.target.value })
                    }
                  />
                ) : (
                  user.email
                )}
              </td>
              <td>
                {editingUser === user.id ? (
                  <input
                    type="text"
                    value={editedUser.department}
                    onChange={(e) =>
                      setEditedUser({
                        ...editedUser,
                        department: e.target.value,
                      })
                    }
                  />
                ) : (
                  user.department
                )}
              </td>
              <td>
                {editingUser === user.id ? (
                  <input
                    type="text"
                    value={editedUser.role}
                    onChange={(e) =>
                      setEditedUser({ ...editedUser, role: e.target.value })
                    }
                  />
                ) : (
                  user.role
                )}
              </td>
              <td>
                {editingUser === user.id ? (
                  <>
                    <button onClick={handleSaveUser}>Save</button>
                    <button onClick={() => setEditingUser(null)}>Cancel</button>
                  </>
                ) : (
                  <>
                    <button onClick={() => handleEditUser(user)}>
                      <FaEdit title="Edit" />
                    </button>
                    <button onClick={() => handleDeleteUser(user.id)}>
                      <FaTrash title="Delete" />
                    </button>
                   
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination Controls */}
      <div className="pagination">
        <button
          disabled={currentPage === 1}
          onClick={() => setCurrentPage((prev) => prev - 1)}
        >
          Previous
        </button>
        <span>
          Page {currentPage} of {totalPages}
        </span>
        <button
          disabled={currentPage === totalPages}
          onClick={() => setCurrentPage((prev) => prev + 1)}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default ViewUsers;