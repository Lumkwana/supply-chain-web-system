import React, { useState } from "react";

const AddStock = ({ onStockAdded }) => {
  const [itemName, setItemName] = useState("");
  const [quantity, setQuantity] = useState(0);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

  const addStock = async (name, qty) => {
    try {
      console.log("Adding stock:", { name, qty }); // Debugging log

      const response = await fetch(`${API_URL}/items`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, quantity: qty }), // Ensure the payload matches the backend
      });

      console.log("Response status:", response.status); // Debugging log

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to add stock");
      }

      return true; // Return success
    } catch (error) {
      console.error("Error adding stock:", error.message);
      return false; // Return failure
    }
  };

  const handleAddStock = async (e) => {
    e.preventDefault();

    if (!itemName || quantity <= 0) {
      setError("Item name and quantity are required, and quantity must be greater than 0.");
      return;
    }

    const success = await addStock(itemName, quantity);

    if (success) {
      setError("");
      setSuccessMessage(`Stock added successfully for item: ${itemName}`);
      setItemName("");
      setQuantity(0);

      if (onStockAdded) onStockAdded();

      setTimeout(() => setSuccessMessage(""), 5000);
    } else {
      setError("Failed to add stock. Please try again later.");
    }
  };

  return (
    <div className="add-stock">
      <h2>Add Stock</h2>
      <form onSubmit={handleAddStock}>
        <div className="form-group">
          <label htmlFor="itemName">Item Name</label>
          <input
            type="text"
            id="itemName"
            value={itemName}
            onChange={(e) => setItemName(e.target.value)}
            placeholder="Enter item name"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="quantity">Quantity</label>
          <input
            type="number"
            id="quantity"
            value={quantity}
            onChange={(e) => setQuantity(Number(e.target.value))}
            placeholder="Enter quantity"
            min="1"
            required
          />
        </div>
        {error && <p className="error-message">{error}</p>}
        {successMessage && <p className="success-message">{successMessage}</p>}
        <button type="submit" className="submit-button">
          Add Stock
        </button>
      </form>
    </div>
  );
};

export default AddStock;
