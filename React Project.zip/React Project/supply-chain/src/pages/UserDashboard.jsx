import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FaSignOutAlt } from "react-icons/fa"; // Import logout icon
import healthLogo from "../assets/health_logo.png";

function UserDashboard() {
  const [orders, setOrders] = useState([]);
  const [items, setItems] = useState([]);
  const [newOrder, setNewOrder] = useState({ item: "", quantity: 1 });
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [user, setUser] = useState(null);
  const [view, setView] = useState("dashboard"); // State to manage the current view
  const [currentOrderPage, setCurrentOrderPage] = useState(1); // Pagination for orders
  const [currentItemPage, setCurrentItemPage] = useState(1); // Pagination for items
  const rowsPerPage = 10; // Number of rows per page
  const navigate = useNavigate();

  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

  useEffect(() => {
    const fetchOrders = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        navigate("/login");
        return;
      }

      try {
        const response = await fetch(`${API_URL}/orders`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.status === 403) {
          localStorage.removeItem("token");
          navigate("/login");
          return;
        }

        if (!response.ok) {
          throw new Error(`Failed to fetch orders: ${response.statusText}`);
        }

        const data = await response.json();
        setOrders(data);
      } catch (error) {
        setError("Failed to fetch orders. Please try again later.");
      }
    };

    const fetchItems = async () => {
      try {
        const response = await fetch(`${API_URL}/items`);
        if (!response.ok) {
          throw new Error("Failed to fetch items");
        }
        const data = await response.json();
        setItems(data);
      } catch (error) {
        setError("Failed to fetch items. Please try again later.");
      }
    };

    const userInfo = JSON.parse(localStorage.getItem("user"));
    setUser(userInfo);

    fetchOrders();
    fetchItems();

    const interval = setInterval(fetchItems, 10000);
    return () => clearInterval(interval);
  }, [navigate, API_URL]);

  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login");
      return;
    }

    try {
      const response = await fetch(`${API_URL}/orders`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(newOrder),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to place order");
      }

      const data = await response.json();
      setOrders((prevOrders) => [
        { id: data.orderId, item: newOrder.item, quantity: newOrder.quantity, status: "Pending" },
        ...prevOrders,
      ]);
      setNewOrder({ item: "", quantity: 1 });
      setSuccessMessage("Order placed successfully!");

      setTimeout(() => {
        setSuccessMessage("");
      }, 5000);
    } catch (error) {
      setError(error.message || "Failed to place order. Please try again later.");
      setTimeout(() => {
        setError("");
      }, 5000);
    }
  };

  const handleConfirmDelivery = async (orderId) => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login");
      return;
    }

    try {
      const response = await fetch(`${API_URL}/orders/${orderId}/confirm-delivery`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        // Try to get error message from backend
        let msg = "Failed to confirm delivery";
        try {
          const errData = await response.json();
          if (errData && errData.error) msg = errData.error;
        } catch {}
        throw new Error(msg);
      }

      // Update the order in the UI immediately (fallback if fetch fails)
      setOrders((prevOrders) =>
        prevOrders.map((order) =>
          (order.id === orderId || order.order_id === orderId)
            ? { ...order, user_delivery_confirmation: "Confirmed" }
            : order
        )
      );

      setSuccessMessage("Delivery confirmed successfully!");
      setTimeout(() => {
        setSuccessMessage("");
      }, 5000);
    } catch (error) {
      setError(error.message || "Failed to confirm delivery. Please try again later.");
      setTimeout(() => {
        setError("");
      }, 5000);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/login");
  };

  const fetchOrderHistory = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login");
      return;
    }

    try {
      const response = await fetch(`${API_URL}/order-history`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch order history");
      }

      const data = await response.json();
      setOrders(data);
      setView("orderHistory");
    } catch (error) {
      setError("Failed to fetch order history. Please try again later.");
    }
  };

  const handleItemChange = (itemName) => {
    setNewOrder({ ...newOrder, item: itemName });
  };

  const indexOfLastOrder = currentOrderPage * rowsPerPage;
  const indexOfFirstOrder = indexOfLastOrder - rowsPerPage;
  const currentOrders = orders.slice(indexOfFirstOrder, indexOfLastOrder);
  const totalOrderPages = Math.ceil(orders.length / rowsPerPage);

  const indexOfLastItem = currentItemPage * rowsPerPage;
  const indexOfFirstItem = indexOfLastItem - rowsPerPage;
  const currentItems = items.slice(indexOfFirstItem, indexOfLastItem);
  const totalItemPages = Math.ceil(items.length / rowsPerPage);

  const getOrdersPlacedCount = () => orders.length;
  const getApprovedOrdersCount = () => orders.filter(order => order.status === "Approved").length;
  const getPendingOrdersCount = () => orders.filter(order => order.status === "Pending").length;

  const renderDashboard = () => (
    <>
      <section className="quick-stats">
        <div className="stat-card">
          <h3>Orders Placed</h3>
          <p>{getOrdersPlacedCount()}</p>
        </div>
        <div className="stat-card">
          <h3>Approved Orders</h3>
          <p>{getApprovedOrdersCount()}</p>
        </div>
        <div className="stat-card">
          <h3>Pending Orders</h3>
          <p>{getPendingOrdersCount()}</p>
        </div>
      </section>

      <section className="recent-orders">
        <h2>Recent Orders</h2>
        <table className="orders-table">
          <thead>
            <tr>
              <th>Order Number</th>
              <th>Item</th>
              <th>Order Status</th>
              <th>User Delivery Confirmation</th>
            </tr>
          </thead>
          <tbody>
            {currentOrders.map((order) => (
              <tr key={order.id || order.order_id}>
                <td>TDH{order.id || order.order_id}</td>
                <td>{order.item}</td>
                <td>
                  <span
                    style={{
                      color:
                        (order.status?.toLowerCase?.() === "delivered")
                          ? "green"
                          : (order.status?.toLowerCase?.() === "pending")
                          ? "orange"
                          : "red",
                      fontWeight: "bold",
                    }}
                  >
                    {order.status}
                  </span>
                </td>
                <td>
                  {/* Show Confirm Delivery button if status is delivered and not confirmed */}
                  {(
                    // Accept both "Delivered" and "delivered" for status and deliver_status
                    (String(order.status || "").toLowerCase() === "delivered" ||
                     String(order.deliver_status || "").toLowerCase() === "delivered")
                    &&
                    String(order.user_delivery_confirmation || "").toLowerCase() !== "confirmed"
                  ) ? (
                    <button
                      type="button"
                      onClick={e => {
                        e.stopPropagation();
                        // Optimistically update UI immediately
                        setOrders(prevOrders =>
                          prevOrders.map(o =>
                            (o.id === (order.id || order.order_id) || o.order_id === (order.id || order.order_id))
                              ? { ...o, user_delivery_confirmation: "Confirmed" }
                              : o
                          )
                        );
                        handleConfirmDelivery(order.id || order.order_id);
                      }}
                      className="bg-blue-500 px-3 py-1 rounded hover:bg-blue-700"
                      style={{ cursor: "pointer" }}
                      tabIndex={0}
                    >
                      Confirm Delivery
                    </button>
                  ) : String(order.user_delivery_confirmation || "").toLowerCase() === "confirmed" ? (
                    <span style={{ color: "green", fontWeight: "bold" }}>Confirmed</span>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="pagination">
          <button
            disabled={currentOrderPage === 1}
            onClick={() => setCurrentOrderPage((prev) => prev - 1)}
          >
            Previous
          </button>
          <span>
            Page {currentOrderPage} of {totalOrderPages}
          </span>
          <button
            disabled={currentOrderPage === totalOrderPages}
            onClick={() => setCurrentOrderPage((prev) => prev + 1)}
          >
            Next
          </button>
        </div>
      </section>

      <section className="order-form">
        <h2>Place New Order</h2>
        <form onSubmit={handlePlaceOrder}>
          <label htmlFor="item">Select Item:</label>
          <select
            id="item"
            value={newOrder.item}
            onChange={(e) => handleItemChange(e.target.value)}
            required
          >
            <option value="">Select Item</option>
            {items.map((item) => (
              <option key={item.id} value={item.name} disabled={item.quantity === 0}>
                {item.name} (Available: {item.quantity})
              </option>
            ))}
          </select>
          {newOrder.item && (
            <p>Available Stock: {items.find(item => item.name === newOrder.item)?.quantity || 0}</p>
          )}
          <label htmlFor="quantity">Quantity:</label>
          <input
            type="number"
            id="quantity"
            min="1"
            max={items.find(item => item.name === newOrder.item)?.quantity || 1}
            value={newOrder.quantity}
            onChange={(e) => setNewOrder({ ...newOrder, quantity: e.target.value })}
            required
          />
          <button type="submit" disabled={!newOrder.item || items.find(item => item.name === newOrder.item)?.quantity === 0}>
            Place Order
          </button>
        </form>
      </section>
    </>
  );

  const renderOrderHistory = () => (
    <>
      <h1>Order History</h1>
      {error && <p className="error-message">{error}</p>}
      <ul>
        {orders.map(order => (
          <li key={order.id}>
            Order #{order.id}: {order.item} - 
            <span
              style={{
                color: order.status === "Delivered" ? "green" : order.status === "Pending" ? "orange" : "red",
                fontWeight: "bold",
                marginLeft: "5px"
              }}
            >
              {order.status}
            </span>
          </li>
        ))}
      </ul>
      <button onClick={() => setView("dashboard")} className="bg-blue-500 px-3 py-1 rounded hover:bg-blue-700 mt-4">
        Back to Dashboard
      </button>
    </>
  );

  const renderProfile = () => (
    <>
      <h1>User Profile</h1>
      <p>Username: {user?.username}</p>
      <p>Surname: {user?.surname}</p>
      <p>Email: {user?.email}</p>
      <p>Department: {user?.department}</p>
      <button onClick={() => setView("dashboard")} className="bg-blue-500 px-3 py-1 rounded hover:bg-blue-700 mt-4">
        Back to Dashboard
      </button>
    </>
  );

  return (
    <div className="dashboard-container w-full">
      <nav className="navbar">
        <button onClick={() => setView("profile")} className="bg-blue-500 px-3 py-1 rounded hover:bg-blue-700 mr-2 mb-2">
          Profile
        </button>
        <button onClick={fetchOrderHistory} className="bg-blue-500 px-3 py-1 rounded hover:bg-blue-700 mr-2 mb-2">
          Order History
        </button>
        <button onClick={handleLogout} className="bg-red-500 px-3 py-1 rounded hover:bg-red-700 mb-2 flex items-center">
          <FaSignOutAlt className="mr-2" /> Logout
        </button>
      </nav>
      
      <div className="main-content">
        <h1>
          <img src={healthLogo} alt="Health Logo" className="health-logo" />
        </h1>

        <h2>Welcome {user?.username} {user?.surname}</h2>

        {view === "dashboard" && renderDashboard()}
        {view === "orderHistory" && renderOrderHistory()}
        {view === "profile" && renderProfile()}

        {successMessage && <p className="success-message">{successMessage}</p>}
        {error && <p className="error-message">{error}</p>}
      </div>
    </div>
  );
}

export default UserDashboard;