# Code Citations

## License: unknown
https://github.com/nguyendangtinhdx/NodeJS/tree/d3b756bf948b642e9714313ef36ae7111cbc6e16/api_nodejs/api/db.js

```
;

const db = mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME |
```


## License: unknown
https://github.com/trungthuya5/ThietKeWebserverGiamSatVaDieuKhienThietBiTrongGiaDinhOnline/tree/a85436c86a8696aeffe9ece95176b4f932a6215a/api/db.js

```
);

const db = mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME
```

