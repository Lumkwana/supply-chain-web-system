import { useState } from "react";
import { useNavigate } from "react-router-dom";
import ErrorBoundary from "../components/ErrorBoundary";
import "../App.css";

function Register() {
  const [username, setUsername] = useState("");
  const [surname, setSurname] = useState("");
  const [persal_number, setPersalNumber] = useState("");
  const [email, setEmail] = useState("");
  const [department, setDepartment] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState("user"); // Default role
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

  const handleRegister = async (e) => {
    e.preventDefault();

    if (!username || !surname || !persal_number || !email || !department || !password || !confirmPassword) {
      setError("All fields are required!");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match!");
      return;
    }

    try {
      const response = await fetch(`${API_URL}/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username,
          surname,
          persal_number,
          email,
          department,
          password,
          role, // Include role in the request
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        setError(errorData.error || "Registration failed");
        return;
      }

      setError("");
      setSuccess(true);
    } catch (error) {
      setError("Server error. Please try again later.");
    }
  };

  const departments = [
    "Admin", "Finance", "Logistics", "Admission Casualty", "Admission Opd", "Casualty", "CEO", "CEO Pa",
    "Clinical Manager", "Cleaning", "Communication", "Control Security", "Dental Clinic", "Dietician", "DID",
    "Environmental health", "Eye Clinic", "Facility Manager", "Finance Revenue", "Human Resource", "Human Resource Manager",
    "Helpdesk", "Infection Control", "IT", "Kitchen", "Labour Relation", "Labour Ward", "MVA", "Mortuary", "Messengers",
    "Maintenance", "Nursing Manager", "Nursing A.D", "Nursing Patient Care", "Occupation Therapy", "OPD", "OPD Operational Manager",
    "Psychology", "Patient Care", "Pharmacy Manager", "Pharmacy OPD", "Pharmacy Store", "Physiotherapy", "Physiotherapy Manager",
    "Procurement", "Procurement Manager", "Records", "Quality Manager", "Quality Officer", "Social Worker", "Speech Therapy",
    "Statistics", "Theatre Manager", "Transport", "Transport Manager", "Ward 1", "Ward 1 Clerk", "Ward 2 Operational Manager",
    "Ward 2", "Ward 3", "Ward 4", "Ward 5", "Ward 6", "Ward 7", "Ward 8", "Ward 19", "Ward 52", "Ward 52B", "Ward 53", "X-Ray"
  ];

  return (
    <ErrorBoundary>
      <div className="register-container" style={{ alignItems: "flex-start", justifyContent: "flex-start" }}>
        <div className="register-form-container">
          <h2 className="form-title">Register New User</h2>

          <form onSubmit={handleRegister} className="register-form">
            <div className="form-group">
             
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your name"
                required
              />
            </div>

            <div className="form-group">
              
              <input
                type="text"
                value={surname}
                onChange={(e) => setSurname(e.target.value)}
                placeholder="Enter your surname"
                required
              />
            </div>

            <div className="form-group">
              
              <input
                type="text"
                value={persal_number}
                onChange={(e) => setPersalNumber(e.target.value)}
                placeholder="Enter your persal number"
                required
              />
            </div>

            <div className="form-group">
              
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                required
              />
            </div>

            <div className="form-group">
             
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                required
              >
                <option value="">Select Department</option>
                {departments.map((dept, index) => (
                  <option key={index} value={dept}>{dept}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Create a password"
                required
              />
            </div>

            <div className="form-group">
            
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm your password"
                required
              />
            </div>

            {error && <p className="error-message">{error}</p>}

            <button type="submit" className="submit-button">
              Register
            </button>
          </form>

          {success && (
            <div className="success-message">
              <p>Registration successful!</p>
            </div>
          )}
        </div>
      </div>
    </ErrorBoundary>
  );
}

export default Register;