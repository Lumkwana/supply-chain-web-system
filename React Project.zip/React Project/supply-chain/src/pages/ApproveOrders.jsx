import React, { useState, useEffect } from "react";

const ApproveOrders = () => {
  const [orders, setOrders] = useState([]);
  const [users, setUsers] = useState([]); // State to store user details
  const [currentPage, setCurrentPage] = useState(1); // State for pagination
  const ordersPerPage = 10; // Number of orders per page
  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

  useEffect(() => {
    fetchOrders();
    fetchUsers(); // Fetch user details
  }, []);

  const fetchOrders = async () => {
    const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000"; // Use Vite's environment variable
    try {
      const token = localStorage.getItem("token"); // Retrieve token from localStorage
      console.log("Token:", token); // Debugging log to check the token
      if (!token) {
        console.error("No token found. Redirecting to login.");
        window.location.href = "/login"; // Redirect to login if token is missing
        return;
      }

      const response = await fetch(`${API_URL}/orders`, {
        headers: {
          Authorization: `Bearer ${token}`, // Include token in the Authorization header
        },
      });

      if (response.status === 403) {
        console.error("Invalid or expired token. Redirecting to login.");
        localStorage.removeItem("token"); // Clear invalid token
        window.location.href = "/login"; // Redirect to login
        return;
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setOrders(data);
    } catch (error) {
      console.error("Error fetching orders:", error.message);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await fetch(`${API_URL}/users`);
      if (!response.ok) {
        throw new Error("Failed to fetch users");
      }
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error("Error fetching users:", error.message);
    }
  };

  const updateOrderStatus = async (orderId, status) => {
    try {
      const token = localStorage.getItem("token");
      const response = await fetch(`${API_URL}/orders/${orderId}/approve`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        // Update the order status in the state immediately
        setOrders((prevOrders) =>
          prevOrders.map((order) =>
            order.order_id === orderId ? { ...order, status: "Approved" } : order
          )
        );
        console.log(`Order ${orderId} approved successfully.`);
      } else {
        console.error(`Failed to approve order ${orderId}`);
      }
    } catch (error) {
      console.error(`Error approving order ${orderId}:`, error.message);
    }
  };

  const updateDeliveryStatus = async (orderId) => {
    console.log(`Deliver button clicked for Order ID: ${orderId}`); // Debug log
    try {
      const token = localStorage.getItem("token");
      const response = await fetch(`${API_URL}/orders/${orderId}/deliver`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        // After delivery, fetch orders again to ensure the latest DB state is reflected
        await fetchOrders();
        console.log(`Order ${orderId} marked as delivered successfully.`);
      } else {
        console.error(`Failed to mark order ${orderId} as delivered.`);
      }
    } catch (error) {
      console.error(`Error delivering order ${orderId}:`, error.message);
    }
  };

  // Pagination logic
  const indexOfLastOrder = currentPage * ordersPerPage;
  const indexOfFirstOrder = indexOfLastOrder - ordersPerPage;
  const currentOrders = orders
    .slice() // Create a shallow copy of the orders array
    .sort((a, b) => b.order_id - a.order_id) // Sort by order_id in descending order
    .slice(indexOfFirstOrder, indexOfLastOrder); // Apply pagination
  const totalPages = Math.ceil(orders.length / ordersPerPage);

  
  return (
    <div className="approve-orders">
      <h2>Manage Orders</h2>
      <table className="orders-table">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>User Full Name</th>
             
            <th>Persal Number</th>
            <th>Department</th>
            <th>Item</th>
            <th>Quantity</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {currentOrders.map((order) => (
            <tr key={order.order_id}>
              <td>Order TDH{order.order_id}</td>
              <td>{order.username} {order.surname}</td>
              <td>{order.persal_number}</td>
               <td>{order.department}</td>
              <td>{order.item}</td>
              <td>{order.quantity}</td>
              <td>
                <span
                  style={{
                    color:
                      order.status === "Delivered"
                        ? "green"
                        : order.status === "Pending"
                        ? "orange"
                        : "red",
                    fontWeight: "bold",
                  }}
                >
                  {order.status}
                </span>
              </td>
              <td>
                {order.status === "Pending" && (
                  <button
                    onClick={() => updateOrderStatus(order.order_id, "Approved")}
                    className="bg-green-500 px-3 py-1 rounded hover:bg-green-700"
                  >
                    Approve
                  </button>
                )}
                {order.status === "Approved" && String(order.deliver_status || "").toLowerCase() !== "delivered" && (
                  <button
                    onClick={async () => {
                      await updateDeliveryStatus(order.order_id);
                      // Immediately update both delivery_status and status to "Delivered" in UI
                      setOrders((prevOrders) =>
                        prevOrders.map((o) =>
                          o.order_id === order.order_id
                            ? { ...o, deliver_status: "Delivered", status: "Delivered" }
                            : o
                        )
                      );
                    }}
                    className="bg-blue-500 px-3 py-1 rounded hover:bg-blue-700 ml-2"
                  >
                    Deliver
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination Controls */}
      <div className="pagination">
        <button
          disabled={currentPage === 1}
          onClick={() => setCurrentPage((prev) => prev - 1)}
        >
          Previous
        </button>
        <span>
          Page {currentPage} of {totalPages}
        </span>
        <button
          disabled={currentPage === totalPages}
          onClick={() => setCurrentPage((prev) => prev + 1)}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default ApproveOrders;