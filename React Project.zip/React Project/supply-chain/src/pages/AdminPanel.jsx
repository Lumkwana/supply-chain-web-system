import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import ViewStock from "./ViewStock";
import AddStock from "./AddStock";
import ApproveOrders from "./ApproveOrders";
import ViewUsers from "./ViewUsers";
import Register from "./Register";
import { FaBoxes, FaUsers, FaTachometerAlt, FaSignOutAlt } from "react-icons/fa";
import "../App.css";

const AdminPanel = () => {
  const [selectedSection, setSelectedSection] = useState("dashboard");
  const [stockSection, setStockSection] = useState("view-stock");
  const [userSection, setUserSection] = useState("view-users");
  const [orders, setOrders] = useState([]);
  const [totalUsers, setTotalUsers] = useState(0); // State to store total users
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate("/login");
  };

  useEffect(() => {
    const fetchOrders = async () => {
      const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000"; // Use Vite's environment variable
      const token = localStorage.getItem("token");
      if (!token) {
        console.error("No token found. Redirecting to login.");
        navigate("/login");
        return;
      }

      try {
        const response = await fetch(`${API_URL}/orders`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          console.log("Orders fetched from API:", data); // Debugging log
          setOrders(data);
        } else {
          console.error("Failed to fetch orders:", response.statusText);
          const errorData = await response.json();
          console.error("Error details:", errorData);
        }
      } catch (error) {
        console.error("Error fetching orders:", error.message);
      }
    };

    const fetchUsers = async () => {
      const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000"; // Use Vite's environment variable
      const token = localStorage.getItem("token");
      if (!token) {
        console.error("No token found. Redirecting to login.");
        navigate("/login");
        return;
      }

      try {
        const response = await fetch(`${API_URL}/users`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          console.log("Users fetched from API:", data); // Debugging log
          setTotalUsers(data.length);
        } else {
          console.error("Failed to fetch users:", response.statusText);
          const errorData = await response.json();
          console.error("Error details:", errorData);
        }
      } catch (error) {
        console.error("Error fetching users:", error.message);
      }
    };

    if (selectedSection === "dashboard") {
      fetchOrders();
      fetchUsers();
    }
  }, [selectedSection, navigate]);

  const renderStockContent = () => {
    switch (stockSection) {
      case "view-stock":
        return <ViewStock />;
      case "add-stock":
        return <AddStock />;
      case "approve-orders":
        return <ApproveOrders />;
      default:
        return <ViewStock />;
    }
  };

  const renderUserContent = () => {
    switch (userSection) {
      case "view-users":
        return <ViewUsers />;
      case "register-user":
        return <Register />;
      default:
        return <ViewUsers />;
    }
  };

  const handleApproveOrder = async (orderId) => {
    const token = localStorage.getItem("token");
    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_URL || "http://localhost:5000"}/orders/${orderId}/approve`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.ok) {
        setOrders((prevOrders) =>
          prevOrders.map((order) =>
            order.order_id === orderId ? { ...order, status: "Approved" } : order
          )
        );
      } else {
        console.error("Failed to approve order");
      }
    } catch (error) {
      console.error("Error approving order:", error);
    }
  };

  const handleDeliverOrder = async (orderId) => {
    const token = localStorage.getItem("token");
    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_URL || "http://localhost:5000"}/orders/${orderId}/deliver`,
        {
          method: "PATCH",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.ok) {
        setOrders((prevOrders) =>
          prevOrders.map((order) =>
            order.order_id === orderId ? { ...order, deliver_status: "Delivered" } : order
          )
        );
        console.log(`Order ${orderId} marked as delivered.`);
      } else {
        console.error("Failed to mark order as delivered");
      }
    } catch (error) {
      console.error("Error delivering order:", error);
    }
  };

  const renderContent = () => {
    switch (selectedSection) {
      case "stock-management":
        return (
          <div className="admin-section">
            <h2>Stock Management</h2>
            <div className="section-buttons">
              <button onClick={() => setStockSection("view-stock")}>View Stock</button>
              <button onClick={() => setStockSection("add-stock")}>Add Stock</button>
              <button onClick={() => setStockSection("approve-orders")}>Orders</button>
            </div>
            {renderStockContent()}
          </div>
        );
      case "user-management":
        return (
          <div className="admin-section">
            <h2>User Management</h2>
            <div className="section-buttons">
              <button onClick={() => setUserSection("view-users")}>View Users</button>
              <button onClick={() => setUserSection("register-user")}>Register User</button>
            </div>
            {renderUserContent()}
          </div>
        );
      case "orders":
        return (
          <div className="admin-section">
            <h2>Manage User Orders</h2>
            <table>
              <thead>
                <tr>
                  <th>OrderID</th>
                  <th>Persal Number</th>
                  <th>User</th>
                  <th>Item</th>
                  <th>Quantity</th>
                  <th>Status</th>
                  <th>Delivery Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.order_id}>
                    <td>{order.order_id}</td>
                    <td>{order.persal_number}</td>
                    <td>{order.username}</td>
                    <td>{order.item}</td>
                    <td>{order.quantity}</td>
                    <td>{order.status}</td>
                    <td>{order.delivery_status || "Pending"}</td>
                    <td>
                      {order.status === "Pending" && (
                        <button onClick={() => handleApproveOrder(order.order_id)}>
                          Approve
                        </button>
                      )}
                      {order.status === "Approved" && order.deliver_status !== "Delivered" && (
                        <button onClick={() => handleDeliverOrder(order.order_id)}>
                          Deliver
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      default:
        return (
          <div className="admin-section">
            <h2>Dashboard</h2>
            <p>Welcome to the Admin Dashboard</p>
            {/* Quick Stats Section */}
            <div className="quick-stats">
              <div className="stat-card">
                <h3>Total Orders</h3>
                <p>{orders.length}</p>
              </div>
              <div className="stat-card">
                <h3>Pending Orders</h3>
                <p>{orders.filter(order => order.status === "Pending").length}</p>
              </div>
              <div className="stat-card">
                <h3>Approved Orders</h3>
                <p>{orders.filter(order => order.status === "Approved").length}</p>
              </div>
              <div className="stat-card">
                <h3>Total Users</h3>
                <p>{totalUsers}</p>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="admin-panel-container">
      {/* Header */}
      <div className="admin-header">
        <h1>SUPPLY CHAIN ADMIN PANEL</h1>
        <button className="logout-button" onClick={handleLogout}>
          <FaSignOutAlt /> Logout
        </button>
      </div>

      {/* Main Content */}
      <div className="admin-content">
        {/* Sidebar */}
        <div className="admin-sidebar">
          <ul>
            <li>
              <button onClick={() => setSelectedSection("dashboard")}>
                <FaTachometerAlt /> Dashboard
              </button>
            </li>
            <li>
              <button onClick={() => setSelectedSection("stock-management")}>
                <FaBoxes /> Stock Management
              </button>
            </li>
            <li>
              <button onClick={() => setSelectedSection("user-management")}>
                <FaUsers /> User Management
              </button>
            </li>
          </ul>
        </div>

        {/* Main Content */}
        <div className="admin-main-content">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;