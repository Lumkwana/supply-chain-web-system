import React, { useState, useEffect } from "react";
import AddStock from "./AddStock";

const ViewStock = () => {
  const [items, setItems] = useState([]);
  const [editingItem, setEditingItem] = useState(null); // State to store the item being edited
  const [editedItem, setEditedItem] = useState({}); // State to store edited item details
  const [currentPage, setCurrentPage] = useState(1); // State for pagination
  const itemsPerPage = 7; // Number of items per page
  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    try {
      const response = await fetch(`${API_URL}/items`);
      if (!response.ok) {
        throw new Error("Failed to fetch items");
      }
      const data = await response.json();
      setItems(data);
    } catch (error) {
      console.error("Error fetching items:", error.message);
    }
  };

  const handleEditItem = (item) => {
    setEditingItem(item.id); // Set the item being edited
    setEditedItem(item); // Populate the form with the item's current details
  };

  const handleSaveItem = async () => {
    try {
      console.log("Saving item:", editedItem); // Debugging log

      const response = await fetch(`${API_URL}/items/${editingItem}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(editedItem),
      });

      console.log("Response status:", response.status); // Debugging log

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to update item");
      }

      setEditingItem(null); // Exit edit mode
      fetchItems(); // Refresh the items list
    } catch (error) {
      console.error("Error saving item:", error.message);
    }
  };

  const handleDeleteItem = async (itemId) => {
    try {
      console.log("Deleting item with ID:", itemId); // Debugging log

      const response = await fetch(`${API_URL}/items/${itemId}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        throw new Error("Failed to delete item");
      }

      fetchItems(); // Refresh the items list
    } catch (error) {
      console.error("Error deleting item:", error.message);
    }
  };

  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = items.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(items.length / itemsPerPage);

  return (
    <div className="view-stock">
      <AddStock onStockAdded={fetchItems} /> {/* AddStock component to add new stock */}
      <table className="stock-table users-table">
        <thead>
          <tr>
            <th>Item Name</th>
            <th>Quantity Available</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {currentItems.map((item) => (
            <tr key={item.id}>
              <td>
                {editingItem === item.id ? (
                  <input
                    type="text"
                    value={editedItem.name}
                    onChange={(e) =>
                      setEditedItem({ ...editedItem, name: e.target.value })
                    }
                  />
                ) : (
                  item.name
                )}
              </td>
              <td>
                {editingItem === item.id ? (
                  <input
                    type="number"
                    value={editedItem.quantity}
                    onChange={(e) =>
                      setEditedItem({ ...editedItem, quantity: e.target.value })
                    }
                  />
                ) : (
                  item.quantity
                )}
              </td>
              <td>
                {editingItem === item.id ? (
                  <>
                    <button onClick={handleSaveItem}>Save</button>
                    <button onClick={() => setEditingItem(null)}>Cancel</button>
                  </>
                ) : (
                  <>
                    <button onClick={() => handleEditItem(item)}>Edit</button>
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="bg-red-500 px-3 py-1 rounded hover:bg-red-700 ml-2"
                    >
                      Delete
                    </button>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination Controls */}
      <div className="pagination">
        <button
          disabled={currentPage === 1}
          onClick={() => setCurrentPage((prev) => prev - 1)}
        >
          Previous
        </button>
        <span>
          Page {currentPage} of {totalPages}
        </span>
        <button
          disabled={currentPage === totalPages}
          onClick={() => setCurrentPage((prev) => prev + 1)}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default ViewStock;