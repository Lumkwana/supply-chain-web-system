import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function OrderHistory() {
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

  useEffect(() => {
    const fetchOrderHistory = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        navigate("/login");
        return;
      }

      try {
        const response = await fetch(`${API_URL}/order-history`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch order history");
        }

        const data = await response.json();
        setOrders(data);
      } catch (error) {
        console.error("Error fetching order history:", error);
        setError("Failed to fetch order history. Please try again later.");
      }
    };

    fetchOrderHistory();
  }, [navigate, API_URL]);

  return (
    <div className="order-history-container w-full">
      <h1>Order History</h1>
      {error && <p className="error-message">{error}</p>}
      <ul>
        {orders.map(order => (
          <li key={order.id}>Order #{order.id}: {order.item} - {order.status}</li>
        ))}
      </ul>
      <button onClick={() => navigate("/dashboard")} className="bg-blue-500 px-3 py-1 rounded hover:bg-blue-700">
        Back to Dashboard
      </button>
    </div>
  );
}

export default OrderHistory;
