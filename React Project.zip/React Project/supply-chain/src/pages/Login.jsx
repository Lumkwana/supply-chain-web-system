import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../App.css";
import healthLogo from "../assets/health_logo.png";
import supplyChainLogo from "../assets/supply_chain_logo.jpg";

function Login() {
  const [persal_number, setPersalNumber] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("user");
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000"; // Ensure this matches the backend URL

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleLogin = async (e) => {
    e.preventDefault();

    console.log("Login button clicked"); // Debugging log

    try {
      console.log("Sending login request to API:", { persal_number, password, role }); // Debugging log
      const response = await fetch(`${API_URL}/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ persal_number, password, role }),
      });

      console.log("Response status:", response.status); // Debugging log

      if (!response.ok) {
        const errorData = await response.json();
        console.error("Login failed:", errorData.error); // Debugging log
        setError(errorData.error || "Login failed");
        return;
      }

      const data = await response.json();
      console.log("Login successful:", data); // Debugging log

      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));

      if (data.user.role === "admin") {
        navigate("/admin-dashboard");
      } else {
        navigate("/user-dashboard");
      }
    } catch (error) {
      console.error("Error during login:", error.message); // Debugging log
      setError("Server error. Please try again later.");
    }
  };

  return (
    <div className="login-container">
      <div className="login-form-container">
        <div className="logos-wrapper">
          <img src={healthLogo} alt="Health Logo" className="health-logo" />
          <img src={supplyChainLogo} alt="Supply Chain Logo" className="supply-chain-logo" />
        </div>
        <h2>Login</h2>

        <form onSubmit={handleLogin}>
          <div>
            <label>Login as</label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value)}
              required
            >
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
          </div>

          <div>
            <input
              type="text"
              value={persal_number}
              onChange={(e) => setPersalNumber(e.target.value)}
              placeholder="Enter your persal number"
              required
            />
          </div>

          <div style={{ position: "relative" }}>
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              required
              style={{
                width: "60%",
                paddingRight: "1px", // Adjust padding to make space for the icon
              }}
            />
            <span
              onClick={togglePasswordVisibility}
              style={{
                position: "absolute",
                right: "150px",
                top: "50%",
                transform: "translateY(-50%)",
                cursor: "pointer",
                fontSize: "1.2em",
              }}
            >
              {showPassword ? "👁️" : "🙈"}
            </span>
          </div>

          {error && <p className="error-message">{error}</p>}

          <button type="submit">
            Login
          </button>
        </form>
      </div>
    </div>
  );
}

export default Login;