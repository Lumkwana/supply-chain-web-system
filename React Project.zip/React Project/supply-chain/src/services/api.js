import axios from "axios";

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000"; // Use environment variable for backend URL

// Fetch stock items
export const fetchStock = async () => {
  try {
    const response = await axios.get(`${API_URL}/stock`);
    return response.data;
  } catch (error) {
    console.error("Error fetching stock data:", error);
    return [];
  }
};

// Add stock item
export const addStockItem = async (name, quantity) => {
  try {
    await axios.post(`${API_URL}/stock`, { name, quantity });
  } catch (error) {
    console.error("Error adding stock item:", error);
  }
};

// Fetch VA2 requests
export const fetchVA2Requests = async () => {
  try {
    const response = await axios.get(`${API_URL}/va2-requests`);
    return response.data;
  } catch (error) {
    console.error("Error fetching VA2 requests:", error);
    return [];
  }
};

// Add VA2 request
export const addVA2Request = async (item_name, quantity) => {
  try {
    await axios.post(`${API_URL}/va2-requests`, { item_name, quantity });
  } catch (error) {
    console.error("Error adding VA2 request:", error);
  }
};