import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import UserDashboard from "./pages/UserDashboard";
import AdminDashboard from "./pages/AdminPanel";
import OrderHistory from "./pages/OrderHistory";
import Navbar from "./components/Navbar"; // Assuming Navbar is in components

function App() {
  return (
    <Router>
      {/* Navbar is outside of the login and register routes */}
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/*" // The wildcard route will match any path not covered above
          element={<><Navbar /><UserDashboard /></>}
        />
        <Route
          path="/admin-dashboard" 
          element={<><Navbar /><AdminDashboard /></>}
        />
        <Route path="/dashboard" element={<UserDashboard />} />
        <Route path="/order-history" element={<OrderHistory />} />
      </Routes>
    </Router>
  );
}

export default App;
