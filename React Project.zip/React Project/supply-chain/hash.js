import bcrypt from 'bcryptjs';

bcrypt.hash("12345678", 10, function(err, hash) {
  if (err) {
    console.error(err);
  } else {
    console.log("Hashed password:", hash);
  }
});
