const db = require('./db');

db.query('SELECT 1', (err, results) => {
    if (err) {
        console.error('Database query failed:', err);
        return;
    }
    console.log('Database connection successful:', results);
    db.end();
});
