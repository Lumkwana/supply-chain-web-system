require("dotenv").config();
const express = require("express");
const mysql = require("mysql2");
const bcrypt = require("bcrypt");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(cors()); // Ensure CORS is enabled

const SECRET_KEY = process.env.SECRET_KEY || "your_secret_key";

console.log("Environment Variables:", {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

const db = mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "supply-chain",
});

db.connect((err) => {
  if (err) {
    console.error("Database connection failed:", err);
  } else {
    console.log("✅ Connected to MySQL database");
  }
});

const ADMIN_CREDENTIALS = {
  persal_number: "00000000",
  password: "Tshw@n3",
  role: "admin",
};

// Middleware to authenticate and extract user ID from the token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ error: "Access denied. No token provided." });
  }

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) {
      return res.status(403).json({ error: "Invalid token." });
    }
    req.user = user; // Attach the user object to the request
    next();
  });
};

// Register a new user
app.post("/register", async (req, res) => {
  const { username, surname, persal_number, email, department, password, role } = req.body;

  if (!username || !surname || !persal_number || !email || !department || !password || !role) {
    return res.status(400).json({ error: "All fields are required" });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const query = "INSERT INTO users (username, surname, persal_number, email, department, password, role) VALUES (?, ?, ?, ?, ?, ?, ?)";
    db.query(query, [username, surname, persal_number, email, department, hashedPassword, role], (err, results) => {
      if (err) {
        // Most common cause: duplicate persal_number (unique constraint violation)
        if (err.code === "ER_DUP_ENTRY") {
          return res.status(400).json({ error: "Persal number or email already exists" });
        }
        console.error("Error registering user:", err);
        return res.status(500).json({ error: "Server error" });
      }
      res.status(201).json({ message: "User registered successfully" });
    });
  } catch (error) {
    console.error("Error hashing password:", error);
    res.status(500).json({ error: "Server error" });
  }
});

// Authenticate user
app.post("/login", async (req, res) => {
  const { persal_number, password, role } = req.body;

  if (!persal_number || !password || !role) {
    return res.status(400).json({ error: "All fields are required" });
  }

  if (
    persal_number === ADMIN_CREDENTIALS.persal_number &&
    password === ADMIN_CREDENTIALS.password &&
    role === ADMIN_CREDENTIALS.role
  ) {
    const token = jwt.sign({ id: "admin", role: "admin" }, SECRET_KEY, { expiresIn: "1h" });
    return res.json({ token, user: { id: "admin", role: "admin", username: "Admin User" } });
  }

  const query = "SELECT * FROM users WHERE persal_number = ? AND role = ?";
  db.query(query, [persal_number, role], async (err, results) => {
    if (err) {
      console.error("Error fetching user:", err);
      return res.status(500).json({ error: "Server error" });
    }

    if (results.length === 0) {
      return res.status(401).json({ error: "Invalid persal, password, or role" });
    }

    const user = results[0];
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: "Invalid persal or password" });
    }

    const token = jwt.sign({ id: user.id, role: user.role }, SECRET_KEY, { expiresIn: "1h" });
    res.json({ token, user });
  });
});

// Get items
app.get("/items", (req, res) => {
  const query = "SELECT * FROM items";
  db.query(query, (err, results) => {
    if (err) {
      console.error("Error fetching items:", err);
      return res.status(500).json({ error: "Server error" });
    }
    res.json(results);
  });
});

// Add item
app.post("/items", (req, res) => {
  const { name, quantity } = req.body;

  if (!name || quantity === undefined) {
    return res.status(400).json({ error: "Item name and quantity are required" });
  }

  const query = "INSERT INTO items (name, quantity) VALUES (?, ?)";
  db.query(query, [name, quantity], (err, results) => {
    if (err) {
      console.error("Error adding item:", err);
      return res.status(500).json({ error: "Failed to add item" });
    }
    res.status(201).json({ message: "Item added successfully", itemId: results.insertId });
  });
});

// Update item
app.put("/items/:id", (req, res) => {
  const { id } = req.params;
  const { name, quantity } = req.body;

  if (!name || quantity === undefined) {
    return res.status(400).json({ error: "Item name and quantity are required" });
  }

  const query = "UPDATE items SET name = ?, quantity = ? WHERE id = ?";
  db.query(query, [name, quantity, id], (err, results) => {
    if (err) {
      console.error("Error updating item:", err);
      return res.status(500).json({ error: "Failed to update item" });
    }

    if (results.affectedRows === 0) {
      return res.status(404).json({ error: "Item not found" });
    }

    res.json({ message: "Item updated successfully" });
  });
});

// Delete item
app.delete("/items/:id", (req, res) => {
  const { id } = req.params;

  const query = "DELETE FROM items WHERE id = ?";
  db.query(query, [id], (err, results) => {
    if (err) {
      console.error("Error deleting item:", err);
      return res.status(500).json({ error: "Failed to delete item" });
    }

    if (results.affectedRows === 0) {
      return res.status(404).json({ error: "Item not found" });
    }

    res.json({ message: "Item deleted successfully" });
  });
});

// Get all users
app.get("/users", (req, res) => {
  const query = "SELECT id, username, surname, persal_number, email, department, role FROM users";
  db.query(query, (err, results) => {
    if (err) {
      console.error("Error fetching users:", err);
      return res.status(500).json({ error: "Failed to fetch users" });
    }
    res.json(results);
  });
});

// Update user
app.put("/users/:id", (req, res) => {
  const { id } = req.params;
  const { username, surname, email, department, role } = req.body;

  if (!username || !surname || !email || !department || !role) {
    return res.status(400).json({ error: "All fields are required" });
  }

  const query = "UPDATE users SET username = ?, surname = ?, email = ?, department = ?, role = ? WHERE id = ?";
  db.query(query, [username, surname, email, department, role, id], (err, results) => {
    if (err) {
      console.error("Error updating user:", err);
      return res.status(500).json({ error: "Failed to update user" });
    }

    if (results.affectedRows === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ message: "User updated successfully" });
  });
});

// Delete user
app.delete("/users/:id", (req, res) => {
  const { id } = req.params;

  const query = "DELETE FROM users WHERE id = ?";
  db.query(query, [id], (err, results) => {
    if (err) {
      console.error("Error deleting user:", err);
      return res.status(500).json({ error: "Failed to delete user" });
    }

    if (results.affectedRows === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ message: "User deleted successfully" });
  });
});

// Get orders for the logged-in user
app.get("/orders", authenticateToken, (req, res) => {
  if (req.user.role === "admin") {
    const query = `
      SELECT orders.id AS order_id, orders.item, orders.quantity, orders.status, 
             orders.username, orders.surname, orders.department, orders.persal_number,
             orders.deliver_status,
             orders.user_delivery_confirmation
      FROM orders
    `;
    db.query(query, (err, results) => {
      if (err) {
        console.error("Error fetching orders:", err);
        return res.status(500).json({ error: "Failed to fetch orders" });
      }
      return res.json(results);
    });
  } else {
    const userId = req.user.id;
    const query = `
      SELECT orders.id AS order_id, orders.item, orders.quantity, orders.status, 
             orders.username, orders.surname, orders.department, orders.persal_number,
             orders.deliver_status,
             orders.user_delivery_confirmation
      FROM orders
      WHERE orders.user_id = ?
    `;
    db.query(query, [userId], (err, results) => {
      if (err) {
        console.error("Error fetching user orders:", err);
        return res.status(500).json({ error: "Failed to fetch user orders" });
      }
      res.json(results);
    });
  }
});

// Get all orders (Admin only)
app.get("/admin/orders", authenticateToken, (req, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Access denied. Admins only." });
  }

  const query = `
    SELECT orders.id AS order_id, orders.item, orders.quantity, orders.status, 
           users.username AS user_name, users.persal_number 
    FROM orders 
    INNER JOIN users ON orders.user_id = users.id
  `;
  db.query(query, (err, results) => {
    if (err) {
      console.error("Error fetching orders:", err);
      return res.status(500).json({ error: "Failed to fetch orders" });
    }
    res.json(results);
  });
});

// Approve an order
app.post("/orders/:id/approve", authenticateToken, (req, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Access denied. Admins only." });
  }

  const { id } = req.params;
  const query = "UPDATE orders SET status = 'Approved' WHERE id = ?";
  db.query(query, [id], (err, results) => {
    if (err) {
      console.error("Error approving order:", err);
      return res.status(500).json({ error: "Failed to approve order" });
    }

    if (results.affectedRows === 0) {
      return res.status(404).json({ error: "Order not found" });
    }

    res.json({ message: "Order approved successfully" });
  });
});

// Deliver an order (set deliver_status to 'Delivered', status to 'Delivered', and reset user_delivery_confirmation)
app.patch("/orders/:id/deliver", authenticateToken, (req, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Access denied. Admins only." });
  }

  const { id } = req.params;
  const query = `
    UPDATE orders
    SET deliver_status = 'Delivered',
        status = 'Delivered',
        user_delivery_confirmation = NULL
    WHERE id = ?
  `;
  db.query(query, [id], (err, results) => {
    if (err) {
      console.error("Error delivering order:", err);
      return res.status(500).json({ error: "Failed to deliver order" });
    }

    if (results.affectedRows === 0) {
      return res.status(404).json({ error: "Order not found" });
    }

    res.json({ message: "Order marked as delivered" });
  });
});

// Place a new order
app.post("/orders", authenticateToken, (req, res) => {
  const userId = req.user.id; // Extract user ID from the token
  const { item, quantity } = req.body;

  if (!item || !quantity) {
    return res.status(400).json({ error: "Item and quantity are required" });
  }

  // Fetch the user's full name, department, and persal_number from the users table
  const userQuery = "SELECT username, department, surname, persal_number FROM users WHERE id = ?";
  db.query(userQuery, [userId], (err, userResults) => {
    if (err) {
      console.error("Error fetching user for order:", err);
      return res.status(500).json({ error: "Failed to fetch user for order" });
    }
    if (userResults.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    const { username, department, surname, persal_number } = userResults[0];

    // Make sure your orders table has columns: user_id, username, surname, persal_number, department, item, quantity, status
    const query = "INSERT INTO orders (user_id, username, surname, persal_number, department, item, quantity, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')";
    db.query(query, [userId, username, surname, persal_number, department, item, quantity], (err, results) => {
      if (err) {
        console.error("Error placing order:", err);
        return res.status(500).json({ error: "Failed to place order" });
      }
      res.status(201).json({ message: "Order placed successfully", orderId: results.insertId });
    });
  });
});

// Get order history for the logged-in user
app.get("/order-history", authenticateToken, (req, res) => {
  const userId = req.user.id; // Extract user ID from the token
  const query = "SELECT * FROM orders WHERE user_id = ?";
  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error("Error fetching order history:", err);
      return res.status(500).json({ error: "Failed to fetch order history" });
    }
    res.json(results);
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
